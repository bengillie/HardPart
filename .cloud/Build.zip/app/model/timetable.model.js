"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Lessons = /** @class */ (function () {
    function Lessons() {
    }
    return Lessons;
}());
exports.Lessons = Lessons;
var Periods = /** @class */ (function () {
    function Periods() {
    }
    return Periods;
}());
exports.Periods = Periods;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidGltZXRhYmxlLm1vZGVsLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsidGltZXRhYmxlLm1vZGVsLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBRUE7SUFBQTtJQU9BLENBQUM7SUFBRCxjQUFDO0FBQUQsQ0FBQyxBQVBELElBT0M7QUFQWSwwQkFBTztBQVNwQjtJQUFBO0lBSUEsQ0FBQztJQUFELGNBQUM7QUFBRCxDQUFDLEFBSkQsSUFJQztBQUpZLDBCQUFPIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgVGltZSB9IGZyb20gXCJAYW5ndWxhci9jb21tb25cIjtcclxuXHJcbmV4cG9ydCBjbGFzcyBMZXNzb25zIHtcclxuICAgIHVzZXJpZDogbnVtYmVyO1xyXG4gICAgZGF0ZTogRGF0ZTtcclxuICAgIHRpbWU6IFRpbWU7XHJcbiAgICB0ZWFjaGVyOiBzdHJpbmc7XHJcbiAgICBzdWJqZWN0OiBzdHJpbmc7XHJcbiAgICBjbGFzczogc3RyaW5nO1xyXG59XHJcblxyXG5leHBvcnQgY2xhc3MgUGVyaW9kcyB7XHJcbiAgICBuYW1lOiBzdHJpbmc7XHJcbiAgICBkYXRlOiBEYXRlO1xyXG4gICAgdGltZTogVGltZTtcclxufSJdfQ==
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var UserModel = /** @class */ (function () {
    function UserModel() {
    }
    return UserModel;
}());
exports.UserModel = UserModel;
var UserType;
(function (UserType) {
    UserType[UserType["student"] = 0] = "student";
    UserType[UserType["parent"] = 1] = "parent";
})(UserType = exports.UserType || (exports.UserType = {}));
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidXNlci5tb2RlbC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbInVzZXIubW9kZWwudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFBQTtJQUFBO0lBTUEsQ0FBQztJQUFELGdCQUFDO0FBQUQsQ0FBQyxBQU5ELElBTUM7QUFOWSw4QkFBUztBQVF0QixJQUFZLFFBR1g7QUFIRCxXQUFZLFFBQVE7SUFDaEIsNkNBQVcsQ0FBQTtJQUNYLDJDQUFVLENBQUE7QUFDZCxDQUFDLEVBSFcsUUFBUSxHQUFSLGdCQUFRLEtBQVIsZ0JBQVEsUUFHbkIiLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgY2xhc3MgVXNlck1vZGVsIHtcclxuICAgIGlkOiBudW1iZXI7XHJcbiAgICB1c2VybmFtZTogc3RyaW5nO1xyXG4gICAgcGFzc3dvcmQ6IHN0cmluZztcclxuICAgIGJpcnRoZGF0ZTogRGF0ZTsgICBcclxuICAgIHVzZXJ0eXBlOiBVc2VyVHlwZTsgXHJcbn1cclxuXHJcbmV4cG9ydCBlbnVtIFVzZXJUeXBlIHtcclxuICAgIHN0dWRlbnQgPSAwLFxyXG4gICAgcGFyZW50ID0gMVxyXG59XHJcbiJdfQ==
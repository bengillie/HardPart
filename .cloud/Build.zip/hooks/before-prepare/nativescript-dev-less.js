module.exports = require("nativescript-dev-less/lib/before-prepare.js");

import { Injectable } from '@angular/core';

import { Lessons, Periods } from '../model/timetable.model';
import { UserModel, UserType } from '../model/user.model';

@Injectable()
export class TimetableService {

    constructor() { }
    
}

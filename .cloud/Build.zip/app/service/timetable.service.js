"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var TimetableService = /** @class */ (function () {
    function TimetableService() {
    }
    TimetableService = __decorate([
        core_1.Injectable(),
        __metadata("design:paramtypes", [])
    ], TimetableService);
    return TimetableService;
}());
exports.TimetableService = TimetableService;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidGltZXRhYmxlLnNlcnZpY2UuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJ0aW1ldGFibGUuc2VydmljZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUFBLHNDQUEyQztBQU0zQztJQUVJO0lBQWdCLENBQUM7SUFGUixnQkFBZ0I7UUFENUIsaUJBQVUsRUFBRTs7T0FDQSxnQkFBZ0IsQ0FJNUI7SUFBRCx1QkFBQztDQUFBLEFBSkQsSUFJQztBQUpZLDRDQUFnQiIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuXHJcbmltcG9ydCB7IExlc3NvbnMsIFBlcmlvZHMgfSBmcm9tICcuLi9tb2RlbC90aW1ldGFibGUubW9kZWwnO1xyXG5pbXBvcnQgeyBVc2VyTW9kZWwsIFVzZXJUeXBlIH0gZnJvbSAnLi4vbW9kZWwvdXNlci5tb2RlbCc7XHJcblxyXG5ASW5qZWN0YWJsZSgpXHJcbmV4cG9ydCBjbGFzcyBUaW1ldGFibGVTZXJ2aWNlIHtcclxuXHJcbiAgICBjb25zdHJ1Y3RvcigpIHsgfVxyXG4gICAgXHJcbn1cclxuIl19
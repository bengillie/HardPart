"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Homework = /** @class */ (function () {
    function Homework() {
    }
    return Homework;
}());
exports.Homework = Homework;
var HomeworkStatus;
(function (HomeworkStatus) {
    HomeworkStatus["todo"] = "TODO";
    HomeworkStatus["done"] = "DONE";
    HomeworkStatus["removed"] = "REMOVED";
})(HomeworkStatus = exports.HomeworkStatus || (exports.HomeworkStatus = {}));
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaG9tZXdvcmsubW9kZWwuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJob21ld29yay5tb2RlbC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUFBO0lBQUE7SUFTQSxDQUFDO0lBQUQsZUFBQztBQUFELENBQUMsQUFURCxJQVNDO0FBVFksNEJBQVE7QUFXckIsSUFBWSxjQUlYO0FBSkQsV0FBWSxjQUFjO0lBQ3RCLCtCQUFhLENBQUE7SUFDYiwrQkFBYSxDQUFBO0lBQ2IscUNBQW1CLENBQUE7QUFDdkIsQ0FBQyxFQUpXLGNBQWMsR0FBZCxzQkFBYyxLQUFkLHNCQUFjLFFBSXpCIiwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IGNsYXNzIEhvbWV3b3JrIHtcclxuICAgIGlkOiBudW1iZXI7XHJcbiAgICBzdWJqZWN0OiBzdHJpbmc7XHJcbiAgICB0YXNrOiBzdHJpbmc7XHJcbiAgICBjcmVhdGVkQnk6IHN0cmluZztcclxuICAgIGNyZWF0ZWREYXRlOiBEYXRlO1xyXG4gICAgYXR0YWNoZWRGaWxlczogYm9vbGVhbjtcclxuICAgIGR1ZURhdGU6IERhdGU7XHJcbiAgICBzdGF0dXM6IEhvbWV3b3JrU3RhdHVzO1xyXG59XHJcblxyXG5leHBvcnQgZW51bSBIb21ld29ya1N0YXR1cyB7XHJcbiAgICB0b2RvID0gXCJUT0RPXCIsXHJcbiAgICBkb25lID0gXCJET05FXCIsXHJcbiAgICByZW1vdmVkID0gXCJSRU1PVkVEXCIsXHJcbn0iXX0=